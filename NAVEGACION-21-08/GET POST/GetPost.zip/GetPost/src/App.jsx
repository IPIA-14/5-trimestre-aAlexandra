import { BrowserRouter, Routes, Route } from "react-router-dom"
import EmpleadoGet from "./EmpleadoGet"
import CrearEmpleado from "./CrearEmpleado"
import Empresa from "./Empresa"
import CrearEmpresa from "./CrearEmpresa"
import Departamento from "./Departamento"
import CrearDep from "./CrearDep"
import Nav from "./Nav"
import ActualizarEmpleado from "./ActualizarEmpleado"
import ActualizarEmpresa from "./ActualizaEmpresa"
import ActualizarDepartamento from "./ActualizarDepartamento"

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Nav/>} />
        <Route path="/empleados" element={<EmpleadoGet />} />
        <Route path="/crear-empleado" element={<CrearEmpleado />} />
        <Route path="/empresas" element={<Empresa />} />
        <Route path="/crear-empresa" element={<CrearEmpresa />} />
        <Route path="/departamentos" element={<Departamento />} />
        <Route path="/crear-dep" element={<CrearDep />} />
        <Route path="/empleados/actualizar/:idempleado" element={<ActualizarEmpleado />} />
        <Route path="/empresas/editar/:idempresa" element={<ActualizarEmpresa />} />
        <Route path="/departamentos/editar/:iddepartamento" element={<ActualizarDepartamento />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App

