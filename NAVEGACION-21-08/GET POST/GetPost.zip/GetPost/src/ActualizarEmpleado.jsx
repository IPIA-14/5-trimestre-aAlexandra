import { useState } from "react";
import './App.css';
import {useParams} from "react-router-dom";

function ActualizarEmpleado(){
    const {idempleado} = useParams();
    const [nombre, setNombre] = useState("")
    const [cargo, setCargo] = useState("")
    const [salario, setSalario] = useState("")
    const [fecha, setFecha] = useState("") //para capturas los estados de una varieble como una caja donde nos permite modificarlas con el set
    async function actualizar(e){
        e.preventDefault()
        await fetch(`https://skojryaxbquqtwvuyhfv.supabase.co/rest/v1/empleados?id=eq.${idempleado}`,{
            method:"PATCH",
            headers: {
            "Content-Type": "application/json",
            apikey:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrb2pyeWF4YnF1cXR3dnV5aGZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc1MTQ0MTUsImV4cCI6MjA3MzA5MDQxNX0.nZMSWKNIve_UmSe1KEehy9ocL2FIR25QflnccDRQ998",
            Authorization:"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrb2pyeWF4YnF1cXR3dnV5aGZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc1MTQ0MTUsImV4cCI6MjA3MzA5MDQxNX0.nZMSWKNIve_UmSe1KEehy9ocL2FIR25QflnccDRQ998"
            },//cerp donde se envia la informacion
            body:JSON.stringify({nombre:nombre, cargo:cargo, salario:salario, fecha_ingreso:fecha})
        }).then((res)=>res.json())
    }


    return(
        <div>
            <h2>Actualizar Empleado</h2>
            <form onSubmit={actualizar}>
                <input placeholder="Escriba Nombre" type="text" onChange={(e)=>setNombre(e.target.value)}></input> 
                <input placeholder="Escriba Cargo" type="text" onChange={(e)=>setCargo(e.target.value)}></input> 
                <input placeholder="Escriba Salario" type="text" onChange={(e)=>setSalario(e.target.value)}></input> 
                <input placeholder="Escriba Fecha Ingreso" type="date" onChange={(e)=>setFecha(e.target.value)}></input> 
                <button type="submit">Actualizar</button>
            </form>
        </div>
    )
}
export default ActualizarEmpleado;