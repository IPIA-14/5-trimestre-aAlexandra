import { useState } from "react";

function CrearEmpresas() {
    const [nombre, setNombre] = useState("");
    const [nit, setNit] = useState("");
    const [direccion, setDireccion] = useState("");
    const [telefono, setTelefono] = useState("");
    const [fechaCreacion, setFechaCreacion] = useState("");

    async function guardar(event){
        event.preventDefault()
        await fetch("https://skojryaxbquqtwvuyhfv.supabase.co/rest/v1/empresa",{
            method:"POST",
            headers: {
             
            "Content-Type": "application/json",   
            apikey:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrb2pyeWF4YnF1cXR3dnV5aGZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc1MTQ0MTUsImV4cCI6MjA3MzA5MDQxNX0.nZMSWKNIve_UmSe1KEehy9ocL2FIR25QflnccDRQ998",  
            Authorization:"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrb2pyeWF4YnF1cXR3dnV5aGZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc1MTQ0MTUsImV4cCI6MjA3MzA5MDQxNX0.nZMSWKNIve_UmSe1KEehy9ocL2FIR25QflnccDRQ998"
        },
        body:JSON.stringify({nombre:nombre, nit:nit, direccion:direccion, telefono:telefono, fecha_creacion:fechaCreacion})
        })
    }
    return(
        <div>
            <h2>Crear Empresa</h2>
            <form onSubmit={guardar}>
                <input type="text" placeholder="Nombre" onChange={(e)=>setNombre(e.target.value)}></input>
                <input type="text" placeholder="NIT" onChange={(e)=>setNit(e.target.value)}></input>
                <input type="text" placeholder="Direccion" onChange={(e)=>setDireccion(e.target.value)}></input>
                <input type="text" placeholder="Telefono" onChange={(e)=>setTelefono(e.target.value)}></input>
                <input type="date" placeholder="Fecha de Creacion" onChange={(e)=>setFechaCreacion(e.target.value)}></input>
                <button>Crear</button>
            </form>
        </div>
    )
}
export default CrearEmpresas