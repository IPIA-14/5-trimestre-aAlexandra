import { Link } from "react-router-dom"

function Nav() {
  return (
    <div>
        <h1>Navegacion</h1>
        <nav>
        <Link to="/empleados">Ver Empleados</Link><br></br>
        <Link to="/crear-empleado">Crear Empleado</Link><br></br>
        <Link to="/empresas">Ver Empresas</Link><br></br>
        <Link to="/crear-empresa">Crear Empresa</Link><br></br>
        <Link to="/departamentos">Ver Departamentos</Link><br></br>
        <Link to="/crear-dep">Crear Departamento</Link><br></br>
        </nav>
    </div>
    
  )
}

export default Nav
