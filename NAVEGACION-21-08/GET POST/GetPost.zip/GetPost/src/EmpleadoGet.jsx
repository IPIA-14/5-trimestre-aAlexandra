import { useState, useEffect } from 'react';
import './App.css';
import { useNavigate } from "react-router-dom";


function Empleados() {  

  const navigate = useNavigate();


    const [empleados, setEmpleados] = useState([]);

    useEffect(() => {
        fetch('https://skojryaxbquqtwvuyhfv.supabase.co/rest/v1/empleados?select=*',{
             headers: {
            apikey:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrb2pyeWF4YnF1cXR3dnV5aGZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc1MTQ0MTUsImV4cCI6MjA3MzA5MDQxNX0.nZMSWKNIve_UmSe1KEehy9ocL2FIR25QflnccDRQ998",
            Authorization:"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrb2pyeWF4YnF1cXR3dnV5aGZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc1MTQ0MTUsImV4cCI6MjA3MzA5MDQxNX0.nZMSWKNIve_UmSe1KEehy9ocL2FIR25QflnccDRQ998"
        }
            
        }).then((respuesta) => respuesta.json())
        .then((data) => setEmpleados(data))
       
    }, []);

    function actualizar(id){
      (id)
      navigate(`/empleados/actualizar/${id}`)
    }
    
    async function eliminar(id){
      //alert("Usuario Eliminado")
      await fetch(`https://skojryaxbquqtwvuyhfv.supabase.co/rest/v1/empleados?id=eq.${id}`,{ //url de la api y aqui traemos el id de la peticion de cuando hacemos click
        method:"DELETE", //metodo de eliminacion
        headers: {
          apikey:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrb2pyeWF4YnF1cXR3dnV5aGZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc1MTQ0MTUsImV4cCI6MjA3MzA5MDQxNX0.nZMSWKNIve_UmSe1KEehy9ocL2FIR25QflnccDRQ998",
          Authorization:"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrb2pyeWF4YnF1cXR3dnV5aGZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc1MTQ0MTUsImV4cCI6MjA3MzA5MDQxNX0.nZMSWKNIve_UmSe1KEehy9ocL2FIR25QflnccDRQ998"
        }
      })//.then((res)=>res.json()) //traer los datos, es una respuesta

      .then(() => {
      setEmpleados(empleados.filter(emp => emp.id !== id));}); //actualizamos la lista de empleados
    }

  return (
    <div>
      <h1>Listado de Empleados</h1>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>nombre</th>
            <th>cargo</th>
            <th>salario</th>
            <th>fecha_ingreso</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {
            empleados.map((emp)=>(
              <tr key={emp.id}>
                <td>{emp.id}</td>
                <td>{emp.nombre}</td>
                <td>{emp.cargo}</td>
                <td>{emp.salario}</td>
                <td>{emp.fecha_ingreso}</td>
                <td>
                  <button onClick={()=>actualizar(emp.id)}>actualizar</button>
                  <button onClick={()=>eliminar(emp.id)}>Deleter</button>
                </td>
              </tr>
            ))
          }
        </tbody>
      </table>
    </div>
  );
}   

export default Empleados;
