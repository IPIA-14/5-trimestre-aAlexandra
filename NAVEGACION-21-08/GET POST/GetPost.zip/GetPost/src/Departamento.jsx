import { useState, useEffect } from 'react';
import './App.css';
import { useNavigate } from "react-router-dom";

function Departamento() {

  const navigate = useNavigate();

  const [departamento, setDepartamento] = useState([]);

  useEffect(() => {
    fetch('https://skojryaxbquqtwvuyhfv.supabase.co/rest/v1/departamento', {
      headers: {
        apikey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrb2pyeWF4YnF1cXR3dnV5aGZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc1MTQ0MTUsImV4cCI6MjA3MzA5MDQxNX0.nZMSWKNIve_UmSe1KEehy9ocL2FIR25QflnccDRQ998',
        Authorization: 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrb2pyeWF4YnF1cXR3dnV5aGZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc1MTQ0MTUsImV4cCI6MjA3MzA5MDQxNX0.nZMSWKNIve_UmSe1KEehy9ocL2FIR25QflnccDRQ998'
      }
    })
      .then(res => res.json())
      .then(data => setDepartamento(data));
  }, []);

  function editarDep(id){
      (id)
      navigate(`/departamentos/editar/${id}`)
    }

  async function eliminarDep(id){
       await fetch(`https://skojryaxbquqtwvuyhfv.supabase.co/rest/v1/departamento?id=eq.${id}`,{ //url de la api y aqui traemos el id de la peticion de cuando hacemos click
        method:"DELETE", //metodo de eliminacion
        headers: {
          apikey:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrb2pyeWF4YnF1cXR3dnV5aGZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc1MTQ0MTUsImV4cCI6MjA3MzA5MDQxNX0.nZMSWKNIve_UmSe1KEehy9ocL2FIR25QflnccDRQ998",
          Authorization:"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrb2pyeWF4YnF1cXR3dnV5aGZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc1MTQ0MTUsImV4cCI6MjA3MzA5MDQxNX0.nZMSWKNIve_UmSe1KEehy9ocL2FIR25QflnccDRQ998"
        }
      })//.then((res)=>res.json()) //traer los datos, es una respuesta

      .then(() => {
      setDepartamento(departamento.filter(emp => emp.id !== id));}); //actualizamos la lista de empleados
    }

  return (
    <div className="container-empleados">
      <h1>Departamento</h1>
      <table>
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Empresa Id</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {departamento.map(dep => (
            <tr key={dep.id}>
              <td>{dep.nombre}</td>
              <td>{dep.descripcion}</td>
              <td>{dep.empresa_id}</td>
              <td>
                <button onClick={() => editarDep(dep.id)} className='btn-editar'>Editar</button>
                <button onClick={() => eliminarDep(dep.id)} className='btn-eliminar'>Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Departamento;
