import { useState } from "react";
import { useNavigate, Link } from "react-router-dom"; //Utilizamos la libreria para navegar

function Loguin() {
    const [rol, setRol] = useState(""); //Declaramos la variable rol
    const navigate = useNavigate(); //Declaramos la funcion de navegacion de react router

    const handleSubmit = (e) => { //Funcion para manejar el click del boton la funcion flecha
        e.preventDefault(); //Prevenimos el comportamiento por defecto del boton
        if (rol){
            navigate("/home", {state: {rol} }); //Navegamos a la ruta home con el rol donde este se guarda en un objeto
        }
        else{
            alert("NO has definido ningun rol")
        }
    } 

    return(
        <div>
            <h2>ROl</h2>
            <form onSubmit={handleSubmit}>
                <select value={rol} onChange={(e) => setRol(e.target.value)}> 
                    <option value="">Selecciona un rol</option>
                    <option value="administrador">Administrator</option>
                    <option value="usuario">Usuario</option>
                    <option value="editor">Editor</option>
                </select> 
                <button type="submit">Continuar ✅</button>
            </form> 

            {/*Enlace para home*/}
            {rol && ( //Solo si el rol es definido toma lo que este en rol osea el rol seleccionado
                <h3>
                    <Link to="/home" state={{rol}}> 
                    Ir a home con el rol: {rol}
                    </Link>
                </h3>
                
            )}

         </div>
    )
}

export default Loguin;


