function Error(){
    return(
        <div>
            <h1>Error 404</h1>
            <p>La página que estas buscando no existe, no la he creado JAJAJAAJJAAJ</p>
        </div>
    )
}
export default Error;